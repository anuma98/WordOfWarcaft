import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Menu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boton extends Actor
{
    protected StarScreen op; //se inicializa una variable de tipo StarScreen
        public Boton(StarScreen o) 
    {
        op=o;
    }  
    public void Jugar()
    {
       op.jugar();// se usa a la variable de tipo StarScreen para llamar a la funcion que inicia el juego
    }
    
    public void ayuda()
    {
       op.ayuda();// se usa a la variable de tipo StarScreen para llamar a la funcion que inicia el ayuda
    }
    public void Creditos()
    {
        op.creditos();//se usa a la variable de tipo StarScreen para llamar a la funcion que inicia el Creditos
    }   
}
