import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MuroN here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MuroN extends Muro
{
    /**
     * Act - do whatever the MuroN wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private String namefile;
    
    public MuroN(String namefile)
    {
        this.namefile = namefile;
        setImage(namefile+".png");
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
