import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Creditos here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Creditos extends Boton
{
 public Creditos(StarScreen M){
        super(M);// una variable de tipo StarScreen llamada desde Boton
    }
    public void act() 
    {
        if(Greenfoot.mouseClicked(this)){// si es clickeado esre objeto llama al método Creditos de boton
            super.Creditos();
    }    
 }  
}
