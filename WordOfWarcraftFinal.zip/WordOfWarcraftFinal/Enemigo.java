import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class Enemigo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enemigo extends Personaje
{
    private GreenfootImage imagen1;
    
    public Enemigo(){
        imagen1 = new GreenfootImage("skull2.png");

    }
    public void act()
    {   
        setImage(imagen1);
            
        move();
        daVuelta();
        
    }
    
    public void daVuelta()
    {
        int cont = 0;
        if(atWorldEdge() || canSee(MuroN.class))
        {
            turn(90);
        }
        if(atWorldEdge() || canSee(MuroN.class))
        {
            turn(45);
        }
     }
}