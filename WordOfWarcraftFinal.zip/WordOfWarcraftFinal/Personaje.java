import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class Personaje here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Personaje extends Actor 
{
  
   private static final double WALKING_SPEED = 5.0;
   private int x,y;
   protected int dir;
   private int cont;
   protected List<Muro> Paredes;
 

    public Personaje()
    {
        dir=0;
        Paredes = null;
        cont =2;
    }
    public int getx(){
        return x;
    }
    public int gety(){
        return y;
    }
    public void act()
    {
        cont ++;
        
        if(cont>=12)
        cont=0;
    }

    public int contador(){
        return cont;
    }
    public List<Muro> ListaMuros(){
        return Paredes;
    }
    public void turn(int angle)
    {
        setRotation(getRotation() + angle);
    }
    public void move()
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * WALKING_SPEED);
        int y = (int) Math.round(getY() + Math.sin(angle) * WALKING_SPEED);
        
        setLocation(x, y);
    }
    public boolean atWorldEdge()
    {
        if(getX() < 20 || getX() > getWorld().getWidth() - 20)
            return true;
        if(getY() < 20 || getY() > getWorld().getHeight() - 20)
            return true;
        else
            return false;
    }
    public boolean canSee(Class clss)
    {
        Actor actor = getOneObjectAtOffset(0, 0, clss);
        return actor != null;        
    }
    public void eat(Class clss)
    {
        Actor actor = getOneObjectAtOffset(0, 0, clss);
        if(actor != null) {
            getWorld().removeObject(actor);
        }
    }

}