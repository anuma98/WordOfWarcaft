import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Jugar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Jugar extends Boton
{
    public Jugar(StarScreen M){
        super(M);// una variable de tipo StarScreen llamada desde Boton
     
    }
    public void act() 
    {
        if(Greenfoot.mouseClicked(this)){// si es clickeado esre objeto llama al método jugar de boton
            super.Jugar();
    }    
 }   // Add your action code here.
    }    

