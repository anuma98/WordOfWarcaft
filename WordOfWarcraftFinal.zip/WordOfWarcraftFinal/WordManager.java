import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.*;
import java.util.Random;
import java.util.HashMap;
import java.lang.Math;


/**
 * Write a description of class WordManager here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WordManager
{
    private HashMap<Integer,String> listaP;
    private Random rand = new Random();
    private Word tempal;
    
   public WordManager()
   {
       tempal = new Word();
    }
    
    public String getPalabra()
    {
        //Genero un valor aleatorio para tomar una palabra de la lista al azar y usarla
        // en el juego
        int x = rand.nextInt(45);
        listaP = tempal.getLista();
        return listaP.get(x);
    }
}